module.exports = {
  thirdParty: {
    'js/polyfill.js': ['babel-polyfill']
  },
  mapObj: {
    'src/': "",
    'scss': "css",
    '_': ""
  }
}