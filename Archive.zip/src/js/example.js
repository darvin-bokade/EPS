// Show implementation of MDB with Webpack
$('h1').css('color', '#E3E3');
